package com.example.studentapp.enums;

public enum TeacherStatus {
    PENDING,
    ACCEPTED,
    REJECTED
}
