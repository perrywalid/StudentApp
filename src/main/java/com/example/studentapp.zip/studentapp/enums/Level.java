package com.example.studentapp.enums;

public enum Level {
    BRONZE,
    SILVER,
    GOLD,
    PLATINUM
}
