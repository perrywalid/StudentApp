package com.example.studentapp.controller;

import com.example.studentapp.model.SessionRequest;
import com.example.studentapp.model.Student;
import com.example.studentapp.model.Teacher;
import com.example.studentapp.service.SessionService;
import com.example.studentapp.service.StudentService;
import com.example.studentapp.service.TeacherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.ServletContext;
import java.util.List;

@Controller
@RequestMapping("/students")
public class StudentController {

    @Autowired
    StudentService studentService;

    @Autowired
    TeacherService teacherService;

    @Autowired
    SessionService sessionService;

    @PostMapping("/register")
    public ResponseEntity<String> registerStudent(@ModelAttribute("student") Student student) {
        if(studentService.create(student) != null) {
            return new ResponseEntity<>("Student registered successfully", HttpStatus.CREATED);
        }
        return new ResponseEntity<>("Error during registration!", HttpStatus.UNAUTHORIZED);
    }

    @GetMapping("/register")
    public ModelAndView displayRegisterStudent(Student student) {
        return new ModelAndView("student-register");
    }
    //need java function

    @PostMapping("/login")
    public ModelAndView login(@RequestParam("email") String email, @RequestParam("password") String password) {
        Student student = studentService.login(email, password);
        ModelAndView mav = new ModelAndView();
        if (student != null) {
            mav.setViewName("redirect:/students/home?studentId=" + student.getId());
        } else {
            mav.setViewName("redirect:/students/login"); //TODO: Create a login failed alert
        }
        return mav;
    }



    @GetMapping("/login")
    public ModelAndView login() {
        return new ModelAndView("student-login");
    }

    @GetMapping("/home")
    public ModelAndView home(@RequestParam("studentId") Long studentId) {
        Student student = studentService.getStudentById(studentId);
        ModelAndView mav = new ModelAndView("student-home");
        mav.addObject("student", student);
        return mav;
    }
    @GetMapping("/tutor-selection/{id}")
    public ModelAndView listAll(@PathVariable Long id) {
        Student student = studentService.getStudentById(id);
        ModelAndView mav = new ModelAndView("student-tut-selection");
        mav.addObject("student", student);
        mav.addObject("teachers", teacherService.listAll());
        return mav;
    }

    @GetMapping("/session-request/{id}/{teacherId}")
    public ModelAndView displayRequest(@PathVariable Long id, @PathVariable Long teacherId, SessionRequest sessionRequest) {
        Student student = studentService.getStudentById(id);
        Teacher teacher = teacherService.getTeacherById(teacherId);
        ModelAndView mav = new ModelAndView("student-make-request");
        mav.addObject("student", student);
        mav.addObject("teacher", teacher);
        return mav;
    }

    @PostMapping("/session-request/{id}/{teacherId}")
    public ModelAndView makeRequest(@PathVariable Long id, @PathVariable Long teacherId, SessionRequest sessionRequest) {
        sessionService.requestSession(id, teacherId, sessionRequest);
        return new ModelAndView("redirect:/students/session-request-list/" + id);
    }

    @GetMapping("/session-request-list/{id}")
    public ModelAndView displayRequestList(@PathVariable Long id) {
        ModelAndView mav = new ModelAndView("student-req-list");
        mav.addObject("student", studentService.getStudentById(id));
        mav.addObject("sessionRequests", sessionService.listAllByStudentId(id));
        return mav;
    }

    @GetMapping("/pay/{id}/{sessionId}")
    public ModelAndView displayPayment(@PathVariable Long id, @PathVariable Long sessionId) {
        ModelAndView mav = new ModelAndView("student-payment");
        mav.addObject("student", studentService.getStudentById(id));
        mav.addObject("sessionRequest", sessionService.getSessionById(sessionId));
        return mav;
    }

    @PostMapping("/pay/{id}/{sessionId}")
    public ModelAndView makePayment(@PathVariable Long id, @PathVariable Long sessionId) {
        sessionService.payForSession(sessionId);
        return new ModelAndView("redirect:/students/session-request-list/" + id);
    }
}
