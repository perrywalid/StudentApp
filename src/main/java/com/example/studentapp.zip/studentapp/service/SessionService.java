package com.example.studentapp.service;

import com.example.studentapp.enums.SessionStatus;
import com.example.studentapp.model.SessionRequest;
import com.example.studentapp.model.Teacher;
import com.example.studentapp.repository.AppWalletRepository;
import com.example.studentapp.repository.SessionRepository;
import com.example.studentapp.repository.StudentRepository;
import com.example.studentapp.repository.TeacherRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

import static com.example.studentapp.enums.SessionStatus.*;

@Service
public class SessionService {
    @Autowired
    SessionRepository sessionRepository;

    @Autowired
    AppWalletRepository appWalletRepository;

    @Autowired
    TeacherRepository teacherRepository;

    @Autowired
    StudentRepository studentRepository;

    @Autowired
    AdminService adminService;

    public void payForSession(Long sessionId) {
        SessionRequest session = sessionRepository.findById(sessionId).get();
        //Move to accepted function later
        session.setStatus(ACCEPTED);
        Teacher teacher = session.getTeacher();
        Float appRevenue = Math.min(session.getCost() * 30 / 100, 90);
        session.setCost(session.getCost() - appRevenue);
        adminService.addToWallet(appRevenue);
        //Nove to hosted by both parties
        //teacher.setWallet(teacher.getWallet() + teacher.getHourlyRate() - appRevenue);
        //AppWallet appWallet = appWalletRepository.findAll().get(0);
        //appWallet.setBalance(appWallet.getBalance() + appRevenue);
        //appWallet.setTeacherWallet(appWallet.getTeacherWallet() + teacher.getHourlyRate() - appRevenue);
        //appWalletRepository.save(appWallet);

        teacherRepository.save(teacher);
        sessionRepository.save(session);
    }
    // public void rejectSession(Long sessionId) {
    // requestRequestSession
    public SessionRequest requestSession(Long studentId, Long teacherId, SessionRequest sessionRequest){
        sessionRequest.setStatus(PENDING);
        sessionRequest.setTeacher(teacherRepository.findById(teacherId).get());
        sessionRequest.setStudent(studentRepository.findById(studentId).get());
        sessionRequest.setCost(sessionRequest.getTeacher().getHourlyRate() * sessionRequest.getSessionHours());
        return sessionRepository.save(sessionRequest);
    }
    public List<SessionRequest> listAllByStudentId(Long studentId){
        return sessionRepository.findAllByStudentId(studentId);
    }
    public List<SessionRequest> listAllByTeacherIdAndStatus(Long teacherId, SessionStatus status){
        return sessionRepository.findAllByTeacherIdAndStatusIs(teacherId, status);
    }
    public SessionRequest host(Long sessionId){
        SessionRequest session = sessionRepository.findById(sessionId).get();
        session.setStatus(HOSTEDTEACHER);
        return sessionRepository.save(session);
    }
    public void accept(Long sessionId){
        SessionRequest session = sessionRepository.findById(sessionId).get();
        session.setStatus(PENDINGPAYMENT);
        sessionRepository.save(session);
    }
    public void reject(Long sessionId){
        SessionRequest session = sessionRepository.findById(sessionId).get();
        session.setStatus(REJECTED);
        sessionRepository.save(session);
    }

    public SessionRequest getSessionById(Long id) {
        return sessionRepository.findById(id).get();
    }
}
