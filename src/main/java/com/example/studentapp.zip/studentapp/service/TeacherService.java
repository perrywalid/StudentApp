package com.example.studentapp.service;

import com.example.studentapp.enums.Level;
import com.example.studentapp.model.Teacher;
import com.example.studentapp.repository.TeacherRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

import static com.example.studentapp.enums.Level.*;
import static com.example.studentapp.enums.Level.BRONZE;
import static com.example.studentapp.enums.TeacherStatus.*;

@Service
public class TeacherService {
    @Autowired
    TeacherRepository teacherRepository;


    public List<Teacher> searchTeachers(Long subjectId) {
        return teacherRepository.findTeachersBySubjects(subjectId);
    }

    public Teacher create(Teacher teacher){
        teacher.setStatus(PENDING);
        teacher.setLevel(Level.BRONZE);
        teacher.setFirstLogin(true);
        return teacherRepository.save(teacher);
    }
    public Teacher login(String email, String password){
        Teacher teacher = teacherRepository.findTeacherByEmail(email);
        if(teacher.getPassword().equals(password)){
            return teacher;
        }
        return null;
    }

    public void acceptTemp(Long teacherId, Level level){
        Teacher teacher = teacherRepository.findById(teacherId).get();
        teacher.setStatus(ACCEPTED);
        //changeRate(teacherId, level);
        teacherRepository.save(teacher);
    }

    public void changeRate(Teacher teacher, Level level){
        teacher.setLevel(level);
        if(level == BRONZE){
            teacher.setHourlyRate(200.0F);
        } else if(level == SILVER){
            teacher.setHourlyRate(250.0F);
        } else if(level == GOLD){
            teacher.setHourlyRate(300.0F);
        } else if(level == PLATINUM){
            teacher.setHourlyRate(450.0F);
        }
    }

    public List<Teacher> listAll(){
        List<Teacher> teachers = teacherRepository.findTeachersByStatusIs(ACCEPTED);
        teachers.sort((t1, t2) -> t2.getRating().compareTo(t1.getRating()));
        return teachers;
    }

    public Teacher getTeacherById(Long id){
        return teacherRepository.findById(id).get();
    }
    public Teacher updateTeacher(Teacher teacher){
        return teacherRepository.save(teacher);
    }

    public List<Teacher> getPendingTeachers(){
        return teacherRepository.findTeachersByStatusIs(PENDING);
    }

    public void reject(Long id){
        Teacher teacher = teacherRepository.findById(id).get();
        teacher.setStatus(REJECTED);
        teacherRepository.save(teacher);
    }

    public void accept(Long id, Level level){
        Teacher teacher = teacherRepository.findById(id).get();
        teacher.setStatus(ACCEPTED);
        changeRate(teacher, level);
        teacherRepository.save(teacher);
    }
}
