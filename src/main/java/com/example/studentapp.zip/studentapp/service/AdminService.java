package com.example.studentapp.service;

import com.example.studentapp.model.Admin;
import com.example.studentapp.repository.AdminRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminService {
    @Autowired
    AdminRepository adminRepository;

    public Admin login(String username, String password){
        Admin admin = adminRepository.findAdminByUsername(username);
        if(admin.getPassword().equals(password)){
            return admin;
        }
        return null;
    }

    public void addToWallet(float amount) {
        Admin admin = adminRepository.findAdminByUsername("admin");
        admin.setWallet(admin.getWallet() + amount);
        adminRepository.save(admin);
    }
}
